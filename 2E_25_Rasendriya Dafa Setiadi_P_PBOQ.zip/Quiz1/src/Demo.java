public class Demo {
    public static void main(String[] args) {
        Handphone demo = new Handphone("98989", "ipong 11", "android 10");
        demo.info();
        demo.tambahVol();
        demo.power();
        demo.tambahVol();
        demo.tambahVol();
        demo.kurangVol();
        demo.kurangVol();
        demo.tambahVol();
        // demo.tambahVol();
        // demo.kurangVol();
        demo.mute();
        demo.mute();
        demo.info();
        // demo.info();
    }
}
